import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Healthy Habits Lamp',
  description: '習慣の灯を育てよう',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  )
}
