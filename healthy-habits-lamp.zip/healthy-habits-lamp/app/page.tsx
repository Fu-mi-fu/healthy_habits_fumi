'use client'

import React, { useState, useEffect } from 'react';

const HealthyHabitsLampUI = () => {
  const [streakCount, setStreakCount] = useState(0);
  
  // ステージを計算（1週目、2週目、3週目）
  const getStage = () => {
    if (streakCount >= 21) return 3;
    if (streakCount >= 14) return 2;
    if (streakCount >= 7) return 1;
    return 0;
  };

  const stage = getStage();

  // ステージに応じた背景色
  const getBackgroundColor = () => {
    switch (stage) {
      case 3: return 'bg-gradient-to-b from-[#E8E5DA] to-[#F5F2E8]'; // 朝焼け
      case 2: return 'bg-gradient-to-b from-[#4B5B5B] to-[#5A6A6A]'; // 夜明け前
      case 1: return 'bg-gradient-to-b from-[#2F3A3D] to-[#3A4548]'; // 夜
      default: return 'bg-gradient-to-b from-[#1F2A2D] to-[#2A3538]'; // 深夜
    }
  };

  // ステージに応じた灯の色
  const getLampColor = () => {
    switch (stage) {
      case 3: return '#FFF6D1'; // 明るい暖かい光
      case 2: return '#FFB347'; // オレンジ色の光
      case 1: return '#FFDCA8'; // 淡い黄色の光
      default: return '#FFE8CC'; // ごく淡い光
    }
  };

  // メッセージ
  const getMessage = () => {
    if (streakCount === 0) return '今日から始めましょう';
    if (streakCount === 1) return '今日、あなたの灯がともりました';
    if (streakCount < 7) return '小さな灯が育っています';
    if (streakCount === 7) return '一週間、灯が続いています';
    if (streakCount < 14) return '今日も小さな光が続いています';
    if (streakCount === 14) return '二週間、灯が強くなってきました';
    if (streakCount < 21) return '夜明けが近づいています';
    if (streakCount === 21) return 'あなたの灯が、朝を迎えました';
    return '美しい朝の光です';
  };

  // SVGの葉っぱコンポーネント
  const Leaf = ({ x, y, delay, size = 20 }: { x: number; y: number; delay: number; size?: number }) => (
    <g 
      transform={`translate(${x}, ${y})`}
      className="animate-float"
      style={{ animationDelay: `${delay}s` }}
    >
      <path
        d={`M0,0 Q${size/2},-${size} ${size},-${size/2} Q${size/2},-${size/4} 0,0`}
        fill="#A8D5A8"
        opacity="0.4"
      />
    </g>
  );

  // 光の粒子コンポーネント
  const LightParticle = ({ x, y, delay }: { x: number; y: number; delay: number }) => (
    <circle
      cx={x}
      cy={y}
      r="2"
      fill="#FFF6D1"
      opacity="0.6"
      className="animate-twinkle"
      style={{ animationDelay: `${delay}s` }}
    />
  );

  return (
    <div className={`min-h-screen ${getBackgroundColor()} transition-all duration-3000 ease-in-out relative overflow-hidden`}>
      <style jsx>{`
        @keyframes flicker {
          0%, 100% { 
            opacity: 0.8; 
            transform: scale(1) translateY(0);
          }
          20% { 
            opacity: 0.9; 
            transform: scale(1.05) translateY(-2px);
          }
          40% { 
            opacity: 0.85; 
            transform: scale(0.98) translateY(1px);
          }
          60% { 
            opacity: 0.95; 
            transform: scale(1.02) translateY(-1px);
          }
          80% { 
            opacity: 0.88; 
            transform: scale(0.99) translateY(0);
          }
        }
        
        @keyframes glow {
          0%, 100% { 
            filter: blur(20px);
            transform: scale(1);
          }
          50% { 
            filter: blur(30px);
            transform: scale(1.1);
          }
        }

        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          33% { transform: translateY(-10px) rotate(5deg); }
          66% { transform: translateY(5px) rotate(-5deg); }
        }

        @keyframes twinkle {
          0%, 100% { opacity: 0; transform: scale(0); }
          50% { opacity: 0.6; transform: scale(1); }
        }

        .animate-flicker {
          animation: flicker 3s ease-in-out infinite;
        }

        .animate-glow {
          animation: glow 4s ease-in-out infinite;
        }

        .animate-float {
          animation: float 6s ease-in-out infinite;
        }

        .animate-twinkle {
          animation: twinkle 3s ease-in-out infinite;
        }
      `}</style>

      {/* 2週目以降の装飾要素 */}
      {stage >= 2 && (
        <svg 
          className="absolute inset-0 w-full h-full pointer-events-none"
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
        >
          {/* 葉っぱ */}
          {stage >= 2 && (
            <>
              <Leaf x={20} y={30} delay={0} size={15} />
              <Leaf x={75} y={25} delay={1.5} size={12} />
              <Leaf x={15} y={70} delay={3} size={18} />
              <Leaf x={80} y={65} delay={2} size={14} />
            </>
          )}
          
          {/* 光の粒子 */}
          {stage >= 3 && (
            <>
              <LightParticle x={30} y={20} delay={0} />
              <LightParticle x={50} y={15} delay={0.5} />
              <LightParticle x={70} y={25} delay={1} />
              <LightParticle x={25} y={40} delay={1.5} />
              <LightParticle x={75} y={35} delay={2} />
              <LightParticle x={40} y={60} delay={2.5} />
              <LightParticle x={60} y={55} delay={3} />
            </>
          )}
        </svg>
      )}

      {/* メインコンテンツ */}
      <div className="flex flex-col items-center justify-center min-h-screen relative z-10">
        {/* 灯のコンテナ */}
        <div className="relative mb-12">
          {/* 光の輪（背景のグロー効果） */}
          <div 
            className="absolute inset-0 rounded-full animate-glow"
            style={{
              width: '200px',
              height: '200px',
              background: `radial-gradient(circle, ${getLampColor()}40 0%, transparent 70%)`,
              transform: 'translate(-50%, -50%)',
              top: '50%',
              left: '50%',
            }}
          />
          
          {/* 灯の本体 */}
          <div className="relative w-32 h-40 flex items-end justify-center">
            {/* 炎の形 */}
            <div 
              className="absolute bottom-8 w-16 h-24 rounded-full animate-flicker"
              style={{
                background: `radial-gradient(ellipse at bottom, ${getLampColor()} 0%, ${getLampColor()}CC 50%, transparent 80%)`,
                filter: 'blur(2px)',
              }}
            />
            
            {/* 炎の中心 */}
            <div 
              className="absolute bottom-10 w-8 h-12 rounded-full"
              style={{
                background: `radial-gradient(ellipse at bottom, #FFFFFF 0%, ${getLampColor()} 40%, transparent 70%)`,
              }}
            />
            
            {/* ろうそくの本体 */}
            <div className="w-12 h-16 bg-[#F5E6D3] rounded-t-sm relative z-10">
              <div className="absolute top-0 left-0 right-0 h-2 bg-[#E8D7C3] rounded-t-sm" />
            </div>
          </div>
        </div>

        {/* メッセージ */}
        <div className="text-center px-8">
          <h1 
            className="text-2xl font-light mb-4 transition-colors duration-1000"
            style={{ color: stage >= 2 ? '#3C4A35' : '#E8E5DA' }}
          >
            {getMessage()}
          </h1>
          
          {/* 継続日数 */}
          <p 
            className="text-sm opacity-70 transition-colors duration-1000"
            style={{ color: stage >= 2 ? '#3C4A35' : '#E8E5DA' }}
          >
            {streakCount > 0 && `${streakCount}日目`}
          </p>
        </div>

        {/* デバッグ用ボタン（本番では削除） */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex gap-4">
          <button
            onClick={() => setStreakCount(Math.max(0, streakCount - 1))}
            className="px-4 py-2 bg-white/20 rounded-lg text-sm"
            style={{ color: stage >= 2 ? '#3C4A35' : '#E8E5DA' }}
          >
            −1日
          </button>
          <button
            onClick={() => setStreakCount(streakCount + 1)}
            className="px-4 py-2 bg-white/20 rounded-lg text-sm"
            style={{ color: stage >= 2 ? '#3C4A35' : '#E8E5DA' }}
          >
            +1日
          </button>
          <button
            onClick={() => setStreakCount(0)}
            className="px-4 py-2 bg-white/20 rounded-lg text-sm"
            style={{ color: stage >= 2 ? '#3C4A35' : '#E8E5DA' }}
          >
            リセット
          </button>
        </div>
      </div>

      {/* 底部のグラデーション（地面の表現） */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-32"
        style={{
          background: stage >= 3 
            ? 'linear-gradient(to top, #D4D1C6 0%, transparent 100%)'
            : stage >= 2 
            ? 'linear-gradient(to top, #3A4A4A 0%, transparent 100%)'
            : 'linear-gradient(to top, #1A2528 0%, transparent 100%)'
        }}
      />
    </div>
  );
};

export default HealthyHabitsLampUI;
